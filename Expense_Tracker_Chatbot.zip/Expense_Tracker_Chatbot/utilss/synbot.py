from dotenv import load_dotenv
import os
import cohere

# Load .env from project root
base_dir = os.path.dirname(os.path.dirname(__file__))  
env_path = os.path.join(base_dir, ".env")
load_dotenv(dotenv_path=env_path)

# Get API key
api_key = os.getenv("COHERE_API_KEY")
if not api_key:
    print("⚠️ WARNING: COHERE_API_KEY not found in .env, using fallback key.")
    api_key = "8CWbaDl3pJs3OHEt6fPYXIqhnydgoqLuF6U9PLrl"  # fallback

if not api_key:
    raise ValueError("❌ Cohere API key missing. Please set it in .env or synbot.py.")

# Initialize Cohere client
co = cohere.Client(api_key)


def get_budget_insights(user_query, transactions_text):
    prompt = f"""User query: {user_query}\nTransactions list: {transactions_text}\n
    If the user asks about ***yourself***, simply respond:
    "I am Synbot, a financial assistant to help with budgeting and expense management.""" 

    response = co.chat(
    model="command-a-03-2025",   # <-- new model name
    message=prompt
)


    return response.text.strip()
